n = int(input())
for i in range(n):
    print(n**2)