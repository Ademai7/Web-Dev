def make_pi():
    a = []
    a.append(3)
    a.append(1)
    a.append(4)
    return a