def middle(a,b):
    c = []
    c.append(a[1])
    c.append(b[1])
    return c
