def make_ends(a):
    c = []
    c.append(a[0])
    c.append(a[2])
    return c
