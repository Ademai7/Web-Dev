def love6(a,b):
    if(a == 6 or b == 6):return True
    elif(abs(a+b)==6):return True
    return False