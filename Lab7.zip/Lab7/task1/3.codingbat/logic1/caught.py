def caught(num,birth):
    if(birth==True):
        num+=5
    if(num <= 60): return 0
    elif(60 < num <=80):return 1
    else :return 2