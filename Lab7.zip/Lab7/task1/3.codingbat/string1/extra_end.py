def extra_end(str):
    return str[-2:]*3

