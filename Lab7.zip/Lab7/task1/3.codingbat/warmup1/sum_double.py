def sum(x,y):
    if x==y:
        return (x+y)*2
    return x+y
