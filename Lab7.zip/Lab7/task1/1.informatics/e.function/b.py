def power(a, n):
    return a ** n


a, n = map(float, input().split())
print(power(a, n))