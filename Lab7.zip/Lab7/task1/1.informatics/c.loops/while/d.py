a = int(input()) 
b = 1
while b < a: 
    b = b * 2 
if b == a: 
    print("YES") 
else: 
    print("NO")