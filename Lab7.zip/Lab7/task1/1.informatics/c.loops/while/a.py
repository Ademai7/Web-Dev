i = 1
n = int(input())
while i ** 2 <= n:
    print(i ** 2)
    i += 1 