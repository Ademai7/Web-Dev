i = 0
n = int(input())
while 2 ** i <= n:
    print(2 ** i, end=' ')
    i += 1