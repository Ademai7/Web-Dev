v = int(input())
t = int(input())

s = (v * t) % 109
print(s)
