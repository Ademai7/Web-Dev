import math 

a = int(input())
b = int(input())

sum = pow(a,2) + pow(b,2)

print(math.sqrt(sum))